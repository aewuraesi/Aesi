const todos = [
    {
        id : 'Task ID',
        task: 'Tasks Entered Will Be Displayed Below..'
    }
]

module.exports = todos;