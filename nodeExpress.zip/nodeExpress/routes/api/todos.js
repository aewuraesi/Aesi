const express = require('express');
const router = express.Router();
const todos = require('../../Todos.js');
const uuid = require('uuid');

//set single task
router.get('/:task', (req,res) => {
    const foundTask = todos.some(todo => todo.task === req.params.task)
    if(foundTask){
        res.json(todos.filter(todo => todo.task === req.params.task));
    } else {
        res.status(400).json({msg: `No id with the task ${req.params.task} found!`});
    }
})

//create task
router.post('/', (req,res) => {
    const newTask = {
        id: uuid.v4(),
        task: req.body.task
    };
    if(!newTask.task || !newTask.id){
        return res.status(400).json({
            msg: "Empty tasks cannot be sent"
        })
    }
    todos.push(newTask);
    // res.json({
    //     msg:'Task Creation Successful',
    //     todos});
    res.redirect('/');
    //todos.save(newTask) - this can be used for mongoDB and other such databases
});

//delete task
router.delete('/:task', (req,res) => {
    const foundTask = todos.some(todo => todo.task === req.params.task);

    if(foundTask){
        // res.json({
        //     msg: "Task Deleted",
        //     todos: todos.filter(todo => todo.task !== req.params.task)});
            // res.json({todos: todos.filter(todo => todo.task !== req.params.task)});
            res.redirect('/');
        // next();
    } else {
        res.status(400).json({msg: `No id with the task ${req.params.task} found!`});
    }
});

//gets all tasks
router.get('/', (req,res) => {
    res.json(todos);
});

//update task
// router.put('/:task', (req,res) => {
//     const foundTask = todos.some(todo => todo.task === req.params.task)
//     if(foundTask){
//         const updatedTask = req.body;
//         todos.forEach(todo => {
//             if(todo.task === req.params.task){
//                 todo.task = updatedTask.name ? updatedTask.task : todo.task;

//                 res.json({msg: "Task Updated", todo})
//             }
//         })
//     } else {
//         res.status(400).json({msg: `No id with the task ${req.params.task} found!`});
//     }
// })

module.exports = router;
