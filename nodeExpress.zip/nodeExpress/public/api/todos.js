const todos = [
    {
        id : 'Task ID',
        task: 'Tasks'
    }
]

module.exports = todos;