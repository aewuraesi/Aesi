const express =  require('express');
const path = require('path');
const todos = require('./public/api/todos');
// const uuid = require('uuid');
// const bodyParser = require('body-parser');

const app = express();

//trial middleware
const logger = (req,res,next) => {
    console.log(`${req.protocol}://${req.get('host')}${req.originalUrl}`);
    next();
}
 //initialize middleware
app.use(logger);

//route
app.get('/api/todos', (req,res) => {
    res.json(todos);
});

//static folder
app.use(express.static(path.join(__dirname, 'public')));

//set single task
app.get('/api/todos/:task', (req,res) => {
    const foundTask = todos.some(todo => todo.task === req.params.task)
    if(found){
        res.json(todos.filter(todo => todo.task === req.params.task));
    } else {
        res.status(400).json({msg: `No id with the task ${req.params.task} found!`});
    }
   
})

app.put('/', (req,res,next) => {
    const newTask = {
        id: uuid,
        task: req.body.params
    };
    todos.push(newTask);
    // res.redirect('/');
    // next();
})

const PORT = process.env.PORT || 9000; 
app.listen('PORT', () => {
    console.log(`Server is listening on port ${PORT}`);
})
