const express =  require('express');
const path = require('path');
const exphbs = require('express-handlebars');
const todos = require('./Todos'); 
const app = express();

//middlewares
//logger
// const logger = (req,res,next) => {
//     console.log(`${req.protocol}://${req.get('host')}${req.originalUrl}`);
//     next();
// }

//handlebars
app.engine('handlebars', exphbs({defaultLayout: 'main'}));
app.set('view engine', 'handlebars');

//body-parser
app.use(express.json());
app.use(express.urlencoded({extended: false}));

//Homepage route
app.get("/", (req,res) => {
    res.render('index', {
        title: "Todo App",
        todos
    }
    )
});

 //static folder
app.use(express.static(path.join(__dirname, 'public')));
//tasks api route
app.use('/api/todos', require('./routes/api/todos'));
//initialize middleware
// app.use(logger);



const PORT = 9000; 
app.listen(PORT, () => {
    console.log(`Server is listening on port ${PORT}`);
})
