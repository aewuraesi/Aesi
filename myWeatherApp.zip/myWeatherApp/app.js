const express =  require('express');
const request = require('request');
const exphbs = require('express-handlebars')
const app = express();


//static folder
app.use(express.static('public'));
//body-parser
app.use(express.urlencoded({extended: true}));
//handlebars
app.set('view engine', 'ejs');

app.get('/', function (req, res) {
    res.render('main', {weather: null, error: null});
  })

//weather fetching
app.post('/', (req,res) => {
    const apiKey = "db4d41fb79463d5550b45d5c3c723faa";
    let city = req.body.location;
    let url = `http://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}`;
    
    request(url, (err, response, body) => {
        if(err){
            res.render('main', {weather: null, error: 'Error, please try again'});
        }
        else {
            let weathers = JSON.parse(body);
            console.log(weathers);
            let errmess = `${weathers.message}`
            if(weathers.main == undefined){
              res.render('main', {weather: null , error: errmess});
            }
            else {
                if(weathers.main.temp){
                    let weatherText = (weathers.main.temp-273.15).toFixed(2);
                    let description = `${weathers.weather[0].description}`;
                    let coutname = `${weathers.name}`;
                    let icons = `http://openweathermap.org/img/w/${weathers.weather[0].icon}.png`;
                    let 
                    freeze = `/freeze.jpeg`,
                    cold = '/cold.jpg',
                    cool = '/cool.jpg',
                    optimal = '/optimal.jpg',
                    warm = '/warm.jpg',
                    heat = '/heat.jpg',
                    extreme = '/extreme.jpg',
                    hell = '/hell_on_earth.jpg';

                    const imagechecks = (weatherText) => {
                        if(weatherText >= 50){
                            res.render('main', {location: coutname, weather: weatherText,descrip:description, weatherIcon:icons, img : hell, error: null});
                        }

                        if(weatherText >= 40 && weatherText < 50){
                            res.render('main', {location: coutname, weather: weatherText,descrip:description, weatherIcon:icons, img : extreme, error: null});
                        }

                        if(weatherText >= 35 && weatherText < 40){
                            res.render('main', {location: coutname, weather: weatherText,descrip:description, weatherIcon:icons, img : heat, error: null});
                        }

                       if(weatherText >= 30 && weatherText < 35){
                            res.render('main', {location: coutname, weather: weatherText,descrip:description, weatherIcon:icons, img : warm, error: null});
                        }

                        if(weatherText >= 26 && weatherText < 30){
                            res.render('main', {location: coutname, weather: weatherText,descrip:description, weatherIcon:icons, img : optimal, error: null});
                        }

                        if(weatherText >= 20 && weatherText < 26 ){
                            res.render('main', {location: coutname, weather: weatherText,descrip:description, weatherIcon:icons, img : cool, error: null});
                        }

                        if (weatherText >= 10 && weatherText < 20){
                            res.render('main', {location: coutname, weather: weatherText,descrip:description, weatherIcon:icons, img : cold, error: null});
                        }

                        if(weatherText < 10) {
                            res.render('main', {location: coutname, weather: weatherText,descrip:description, weatherIcon:icons, img : freeze, error: null});
                        }
                    }
                    imagechecks(weatherText);
                }
            }
        }
    });
});

//localhost
const PORT = 3000; 
app.listen(PORT, () => {
    console.log(`Server is listening on port ${PORT}`);
})



// database
// table
// id: 1, name: newuser
// id: 2, name: usertwo


// columns


// Weather

// try{
//     `api call`
// }
// catch(e){
//     if(e.contains)
// }