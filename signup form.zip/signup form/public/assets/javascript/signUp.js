function generateuser(){
    var
    fname = document.getElementById('fname').value,
    lname = document.getElementById('lname').value,
    alias = (fname.substring(0,2) + lname).toLowerCase();
    document.getElementById('uname').value = alias;
    document.getElementById('alias_text').innerHTML = 'You may change the given user name to any of your choice';
  }
  
  function checkEmail(){
    document.getElementById('mandatoryEmail_text').innerHTML = 'You may leave this field blank if you do not have an email';
    var emailID = document.getElementById('emailID');
    if(emailID.value !== ''){
      document.getElementById('emailID').pattern =".+@gmail.com||.+@yahoo.com||.+@hotmail.com"
    }
  }
  
  
  const checkIds = () => {
    var
    pass1 = document.getElementById('pass1').value,
    pass2 = document.getElementById('pass2').value,
    phone = document.getElementById('phoneNumb'),
    name1 = document.getElementById('fname').value,
    name2 = document.getElementById('lname').value;
  
    if(name1===''){
      window.alert("Please enter your first name.");
      return false;
    }
  
    if(name2===''){
      window.alert("Please enter your last name.");
      return false;
    }
  
    if (phone.value == ""){
      window.alert("Please enter your telephone number.");
      phone.focus();
      return false;
    }
  
    if (phone.value.length < 10 || phone.value.length > 10) {
      window.alert("Please enter a valid telephone number.");
      phone.value = "";
      phone.focus();
      return false
    }
  
    if (pass1&&pass2===''){
      window.alert("Please Create A Password");
      return false;
    }
  
    if (pass1!==pass2){
      window.alert('Passwords do not match!');
      document.getElementById('pass1').value = '';
      document.getElementById('pass2').value = '';
      return false;
     }
     window.alert(name1.toUpperCase() + ", REGISTRATION SUCESSFUL");
  }