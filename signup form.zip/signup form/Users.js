const users = [
    // {
    //     // id:'User Id',
    //     // fname: 'First name',
    //     // lname: 'Last name',
    //     // uname: 'User name',
    //     // email: 'email',
    //     // dobirth: 'date of birth',
    //     // phoneNumb:'phone number',
    //     // pass1:'password',
    //     // pass2: 'confirmed password',
    // }
];

module.exports = users;