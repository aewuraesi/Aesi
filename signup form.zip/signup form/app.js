const express = require('express');
const path = require('path');
const exphbs = require('express-handlebars');
const users = require('./Users'); 

const app = express();

//handlebars
app.engine('handlebars', exphbs({defaultLayout: 'main'}));
app.set('view engine', 'handlebars');

//body-parser
app.use(express.json());
app.use(express.urlencoded({extended: false}));

//Homepage route
app.get('/', (req,res) => {
    res.render('index', {
        users
    });
});

//static folder
app.use(express.static(path.join(__dirname, 'public')));

//users api route
app.use('/api/users', require('./routes/api/users'));

const PORT = 8000; 
app.listen(PORT, () => {
    console.log(`Server is listening on port ${PORT}`);
})
