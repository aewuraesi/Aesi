const express = require('express');
const router = express.Router();
const users = require('../../Users');
const uuid = require('uuid');

//gets all users
router.get('/', (req,res) => {
    res.json(users);
});

//create new user
router.post('/', (req,res) => {
    const newUser = {
        id: uuid.v4(),
        fname: req.body.fname,
        lname: req.body.lname,
        uname: req.body.uname,
        email: req.body.email,
        dobirth: req.body.dobirth,
        phoneNumb:req.body.phoneNumb,
        pass1:req.body.pass1,
        pass2: req.body.pass2,
    };
    if(!newUser.fname || !newUser.lname || !newUser.uname || !newUser.email || !newUser.dobirth || !newUser.phoneNumb || !newUser.pass1 || !newUser.pass2 ){
        return res.status(400).json({
            msg: "Empty fields cannot be sent"
        });
    }
    users.push(newUser);
    // res.json({
    //     msg:'Registration Successful',
    //     users
    // });
    res.redirect('/');
});

// //deletes user if necessary
// router.delete('/:fname', (req,res) => {
//     const found = users.some(user => user.fname === req.params.fname);

//     if(found){
//         res.json({
//             msg: "User Info Deleted",
//             users: users.filter(user => user.fname !== req.params.fname)});
//         // next();
//     } else {
//         res.status(404).json({msg: `No id with the user name of ${req.params.fname} found!`});
//     }
// });

//set single user info
// router.get('/:firstName', (req,res) => {
//     const found = users.some(user => user.fname === req.params.fname)
//     if(found){
//         res.json(users.filter(user => user.fname === req.params.fname));
//     } else {
//         res.status(400).json({msg: `No user with the name of ${req.params.fname} found!`});
//     }
// })


module.exports = router;